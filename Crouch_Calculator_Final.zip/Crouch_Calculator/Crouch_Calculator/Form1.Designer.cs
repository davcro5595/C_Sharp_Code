﻿namespace Crouch_Calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EightButton = new System.Windows.Forms.Button();
            this.SevenButton = new System.Windows.Forms.Button();
            this.NineButton = new System.Windows.Forms.Button();
            this.OneButton = new System.Windows.Forms.Button();
            this.FourButton = new System.Windows.Forms.Button();
            this.FiveButton = new System.Windows.Forms.Button();
            this.SixButton = new System.Windows.Forms.Button();
            this.EqualsButton = new System.Windows.Forms.Button();
            this.ThreeButton = new System.Windows.Forms.Button();
            this.DotButton = new System.Windows.Forms.Button();
            this.TwoButton = new System.Windows.Forms.Button();
            this.ZeroButton = new System.Windows.Forms.Button();
            this.ClearEverythingButton = new System.Windows.Forms.Button();
            this.DivisionButton = new System.Windows.Forms.Button();
            this.SquaredButton = new System.Windows.Forms.Button();
            this.MultiplicationButton = new System.Windows.Forms.Button();
            this.SubtractionButton = new System.Windows.Forms.Button();
            this.AdditionButton = new System.Windows.Forms.Button();
            this.ClearButton = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.MemoryClearButton = new System.Windows.Forms.Button();
            this.MemoryStoreButton = new System.Windows.Forms.Button();
            this.MemoryRecallButton = new System.Windows.Forms.Button();
            this.EntryTextBox = new System.Windows.Forms.TextBox();
            this.ResultsTextBox = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // EightButton
            // 
            this.EightButton.Location = new System.Drawing.Point(121, 198);
            this.EightButton.Name = "EightButton";
            this.EightButton.Size = new System.Drawing.Size(75, 23);
            this.EightButton.TabIndex = 0;
            this.EightButton.Text = "8";
            this.EightButton.UseVisualStyleBackColor = true;
            this.EightButton.Click += new System.EventHandler(this.EightButton_Click);
            // 
            // SevenButton
            // 
            this.SevenButton.Location = new System.Drawing.Point(28, 198);
            this.SevenButton.Name = "SevenButton";
            this.SevenButton.Size = new System.Drawing.Size(75, 23);
            this.SevenButton.TabIndex = 1;
            this.SevenButton.Text = "7";
            this.SevenButton.UseVisualStyleBackColor = true;
            this.SevenButton.Click += new System.EventHandler(this.SevenButton_Click);
            // 
            // NineButton
            // 
            this.NineButton.Location = new System.Drawing.Point(210, 198);
            this.NineButton.Name = "NineButton";
            this.NineButton.Size = new System.Drawing.Size(75, 23);
            this.NineButton.TabIndex = 2;
            this.NineButton.Text = "9";
            this.NineButton.UseVisualStyleBackColor = true;
            this.NineButton.Click += new System.EventHandler(this.NineButton_Click);
            // 
            // OneButton
            // 
            this.OneButton.Location = new System.Drawing.Point(28, 262);
            this.OneButton.Name = "OneButton";
            this.OneButton.Size = new System.Drawing.Size(75, 23);
            this.OneButton.TabIndex = 3;
            this.OneButton.Text = "1";
            this.OneButton.UseVisualStyleBackColor = true;
            this.OneButton.Click += new System.EventHandler(this.OneButton_Click);
            // 
            // FourButton
            // 
            this.FourButton.Location = new System.Drawing.Point(28, 230);
            this.FourButton.Name = "FourButton";
            this.FourButton.Size = new System.Drawing.Size(75, 23);
            this.FourButton.TabIndex = 4;
            this.FourButton.Text = "4";
            this.FourButton.UseVisualStyleBackColor = true;
            this.FourButton.Click += new System.EventHandler(this.FourButton_Click);
            // 
            // FiveButton
            // 
            this.FiveButton.Location = new System.Drawing.Point(121, 230);
            this.FiveButton.Name = "FiveButton";
            this.FiveButton.Size = new System.Drawing.Size(75, 23);
            this.FiveButton.TabIndex = 5;
            this.FiveButton.Text = "5";
            this.FiveButton.UseVisualStyleBackColor = true;
            this.FiveButton.Click += new System.EventHandler(this.FiveButton_Click);
            // 
            // SixButton
            // 
            this.SixButton.Location = new System.Drawing.Point(210, 230);
            this.SixButton.Name = "SixButton";
            this.SixButton.Size = new System.Drawing.Size(75, 23);
            this.SixButton.TabIndex = 6;
            this.SixButton.Text = "6";
            this.SixButton.UseVisualStyleBackColor = true;
            this.SixButton.Click += new System.EventHandler(this.SixButton_Click);
            // 
            // EqualsButton
            // 
            this.EqualsButton.Location = new System.Drawing.Point(302, 301);
            this.EqualsButton.Name = "EqualsButton";
            this.EqualsButton.Size = new System.Drawing.Size(75, 23);
            this.EqualsButton.TabIndex = 7;
            this.EqualsButton.Text = "=";
            this.EqualsButton.UseVisualStyleBackColor = true;
            this.EqualsButton.Click += new System.EventHandler(this.EqualsButton_Click);
            // 
            // ThreeButton
            // 
            this.ThreeButton.Location = new System.Drawing.Point(210, 262);
            this.ThreeButton.Name = "ThreeButton";
            this.ThreeButton.Size = new System.Drawing.Size(75, 23);
            this.ThreeButton.TabIndex = 8;
            this.ThreeButton.Text = "3";
            this.ThreeButton.UseVisualStyleBackColor = true;
            this.ThreeButton.Click += new System.EventHandler(this.ThreeButton_Click);
            // 
            // DotButton
            // 
            this.DotButton.Location = new System.Drawing.Point(210, 301);
            this.DotButton.Name = "DotButton";
            this.DotButton.Size = new System.Drawing.Size(75, 23);
            this.DotButton.TabIndex = 9;
            this.DotButton.Text = ".";
            this.DotButton.UseVisualStyleBackColor = true;
            this.DotButton.Click += new System.EventHandler(this.DotButton_Click);
            // 
            // TwoButton
            // 
            this.TwoButton.Location = new System.Drawing.Point(121, 262);
            this.TwoButton.Name = "TwoButton";
            this.TwoButton.Size = new System.Drawing.Size(75, 23);
            this.TwoButton.TabIndex = 10;
            this.TwoButton.Text = "2";
            this.TwoButton.UseVisualStyleBackColor = true;
            this.TwoButton.Click += new System.EventHandler(this.TwoButton_Click);
            // 
            // ZeroButton
            // 
            this.ZeroButton.Location = new System.Drawing.Point(28, 301);
            this.ZeroButton.Name = "ZeroButton";
            this.ZeroButton.Size = new System.Drawing.Size(168, 23);
            this.ZeroButton.TabIndex = 11;
            this.ZeroButton.Text = "0";
            this.ZeroButton.UseVisualStyleBackColor = true;
            this.ZeroButton.Click += new System.EventHandler(this.ZeroButton_Click);
            // 
            // ClearEverythingButton
            // 
            this.ClearEverythingButton.Location = new System.Drawing.Point(121, 169);
            this.ClearEverythingButton.Name = "ClearEverythingButton";
            this.ClearEverythingButton.Size = new System.Drawing.Size(75, 23);
            this.ClearEverythingButton.TabIndex = 13;
            this.ClearEverythingButton.Text = "CE";
            this.ClearEverythingButton.UseVisualStyleBackColor = true;
            this.ClearEverythingButton.Click += new System.EventHandler(this.ClearEverythingButton_Click);
            // 
            // DivisionButton
            // 
            this.DivisionButton.Location = new System.Drawing.Point(302, 169);
            this.DivisionButton.Name = "DivisionButton";
            this.DivisionButton.Size = new System.Drawing.Size(75, 23);
            this.DivisionButton.TabIndex = 14;
            this.DivisionButton.Text = "/";
            this.DivisionButton.UseVisualStyleBackColor = true;
            this.DivisionButton.Click += new System.EventHandler(this.DivisionButton_Click);
            // 
            // SquaredButton
            // 
            this.SquaredButton.Location = new System.Drawing.Point(28, 169);
            this.SquaredButton.Name = "SquaredButton";
            this.SquaredButton.Size = new System.Drawing.Size(75, 23);
            this.SquaredButton.TabIndex = 15;
            this.SquaredButton.Text = "x^2";
            this.SquaredButton.UseVisualStyleBackColor = true;
            this.SquaredButton.Click += new System.EventHandler(this.SquaredButton_Click);
            // 
            // MultiplicationButton
            // 
            this.MultiplicationButton.Location = new System.Drawing.Point(302, 198);
            this.MultiplicationButton.Name = "MultiplicationButton";
            this.MultiplicationButton.Size = new System.Drawing.Size(75, 23);
            this.MultiplicationButton.TabIndex = 16;
            this.MultiplicationButton.Text = "*";
            this.MultiplicationButton.UseVisualStyleBackColor = true;
            this.MultiplicationButton.Click += new System.EventHandler(this.MultiplicationButton_Click);
            // 
            // SubtractionButton
            // 
            this.SubtractionButton.Location = new System.Drawing.Point(302, 230);
            this.SubtractionButton.Name = "SubtractionButton";
            this.SubtractionButton.Size = new System.Drawing.Size(75, 23);
            this.SubtractionButton.TabIndex = 17;
            this.SubtractionButton.Text = "-";
            this.SubtractionButton.UseVisualStyleBackColor = true;
            this.SubtractionButton.Click += new System.EventHandler(this.SubtractionButton_Click);
            // 
            // AdditionButton
            // 
            this.AdditionButton.Location = new System.Drawing.Point(302, 262);
            this.AdditionButton.Name = "AdditionButton";
            this.AdditionButton.Size = new System.Drawing.Size(75, 23);
            this.AdditionButton.TabIndex = 18;
            this.AdditionButton.Text = "+";
            this.AdditionButton.UseVisualStyleBackColor = true;
            this.AdditionButton.Click += new System.EventHandler(this.AdditionButton_Click);
            // 
            // ClearButton
            // 
            this.ClearButton.Location = new System.Drawing.Point(210, 169);
            this.ClearButton.Name = "ClearButton";
            this.ClearButton.Size = new System.Drawing.Size(75, 23);
            this.ClearButton.TabIndex = 19;
            this.ClearButton.Text = "C";
            this.ClearButton.UseVisualStyleBackColor = true;
            this.ClearButton.Click += new System.EventHandler(this.ClearButton_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Crouch_Calculator.Properties.Resources.mathematics_1509559_640;
            this.pictureBox1.Location = new System.Drawing.Point(28, 12);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(128, 82);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // MemoryClearButton
            // 
            this.MemoryClearButton.Location = new System.Drawing.Point(28, 140);
            this.MemoryClearButton.Name = "MemoryClearButton";
            this.MemoryClearButton.Size = new System.Drawing.Size(75, 23);
            this.MemoryClearButton.TabIndex = 21;
            this.MemoryClearButton.Text = "MC";
            this.MemoryClearButton.UseVisualStyleBackColor = true;
            this.MemoryClearButton.Click += new System.EventHandler(this.MemoryClearButton_Click);
            // 
            // MemoryStoreButton
            // 
            this.MemoryStoreButton.Location = new System.Drawing.Point(210, 140);
            this.MemoryStoreButton.Name = "MemoryStoreButton";
            this.MemoryStoreButton.Size = new System.Drawing.Size(75, 23);
            this.MemoryStoreButton.TabIndex = 22;
            this.MemoryStoreButton.Text = "MS";
            this.MemoryStoreButton.UseVisualStyleBackColor = true;
            this.MemoryStoreButton.Click += new System.EventHandler(this.MemoryStoreButton_Click);
            // 
            // MemoryRecallButton
            // 
            this.MemoryRecallButton.Location = new System.Drawing.Point(121, 140);
            this.MemoryRecallButton.Name = "MemoryRecallButton";
            this.MemoryRecallButton.Size = new System.Drawing.Size(75, 23);
            this.MemoryRecallButton.TabIndex = 23;
            this.MemoryRecallButton.Text = "MR";
            this.MemoryRecallButton.UseVisualStyleBackColor = true;
            this.MemoryRecallButton.Click += new System.EventHandler(this.MemoryRecallButton_Click);
            // 
            // EntryTextBox
            // 
            this.EntryTextBox.Location = new System.Drawing.Point(210, 105);
            this.EntryTextBox.Name = "EntryTextBox";
            this.EntryTextBox.ReadOnly = true;
            this.EntryTextBox.Size = new System.Drawing.Size(167, 20);
            this.EntryTextBox.TabIndex = 24;
            this.EntryTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.EntryTextBox.TextChanged += new System.EventHandler(this.EntryTextBox_TextChanged);
            this.EntryTextBox.KeyDown += new System.Windows.Forms.KeyEventHandler(this.EntryTextBox_KeyDown);
            // 
            // ResultsTextBox
            // 
            this.ResultsTextBox.Location = new System.Drawing.Point(210, 74);
            this.ResultsTextBox.Name = "ResultsTextBox";
            this.ResultsTextBox.ReadOnly = true;
            this.ResultsTextBox.Size = new System.Drawing.Size(167, 20);
            this.ResultsTextBox.TabIndex = 25;
            this.ResultsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(403, 339);
            this.Controls.Add(this.ResultsTextBox);
            this.Controls.Add(this.EntryTextBox);
            this.Controls.Add(this.MemoryRecallButton);
            this.Controls.Add(this.MemoryStoreButton);
            this.Controls.Add(this.MemoryClearButton);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.ClearButton);
            this.Controls.Add(this.AdditionButton);
            this.Controls.Add(this.SubtractionButton);
            this.Controls.Add(this.MultiplicationButton);
            this.Controls.Add(this.SquaredButton);
            this.Controls.Add(this.DivisionButton);
            this.Controls.Add(this.ClearEverythingButton);
            this.Controls.Add(this.ZeroButton);
            this.Controls.Add(this.TwoButton);
            this.Controls.Add(this.DotButton);
            this.Controls.Add(this.ThreeButton);
            this.Controls.Add(this.EqualsButton);
            this.Controls.Add(this.SixButton);
            this.Controls.Add(this.FiveButton);
            this.Controls.Add(this.FourButton);
            this.Controls.Add(this.OneButton);
            this.Controls.Add(this.NineButton);
            this.Controls.Add(this.SevenButton);
            this.Controls.Add(this.EightButton);
            this.Name = "Calculator";
            this.Text = "David\'s Calculator";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Calculator_KeyDown);
            this.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.Calculator_KeyPress);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button EightButton;
        private System.Windows.Forms.Button SevenButton;
        private System.Windows.Forms.Button NineButton;
        private System.Windows.Forms.Button OneButton;
        private System.Windows.Forms.Button FourButton;
        private System.Windows.Forms.Button FiveButton;
        private System.Windows.Forms.Button SixButton;
        private System.Windows.Forms.Button EqualsButton;
        private System.Windows.Forms.Button ThreeButton;
        private System.Windows.Forms.Button DotButton;
        private System.Windows.Forms.Button TwoButton;
        private System.Windows.Forms.Button ZeroButton;
        private System.Windows.Forms.Button ClearEverythingButton;
        private System.Windows.Forms.Button DivisionButton;
        private System.Windows.Forms.Button SquaredButton;
        private System.Windows.Forms.Button MultiplicationButton;
        private System.Windows.Forms.Button SubtractionButton;
        private System.Windows.Forms.Button AdditionButton;
        private System.Windows.Forms.Button ClearButton;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button MemoryClearButton;
        private System.Windows.Forms.Button MemoryStoreButton;
        private System.Windows.Forms.Button MemoryRecallButton;
        private System.Windows.Forms.TextBox EntryTextBox;
        private System.Windows.Forms.TextBox ResultsTextBox;
    }
}

