﻿/* David Crouch 
*  CIS 317 
*  Calculator Project   
*  07/10/2021 
* */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Crouch_Calculator
{
    public partial class Calculator : Form
    {
        //initialize variables
        string memory = null;
        string value1, value2; //These values are used for calculating the results
        string _operator; //This value is used for determining what type of math to perform

        //constructor method
        public Calculator()
        {
            InitializeComponent();
        }

        private double Calculate()
        {
            double result = 0; //store the result in a variable

            //perform mathematical calculations
            switch (_operator)
            {
                case "+":
                    result = Addition(Convert.ToDouble(value1), Convert.ToDouble(value2));
                    break;
                case "-":
                    result = Subtraction(Convert.ToDouble(value1), Convert.ToDouble(value2));
                    break;
                case "*":
                    result = Multiplication(Convert.ToDouble(value1), Convert.ToDouble(value2));
                    break;
                case "/":
                    result = Division(Convert.ToDouble(value1), Convert.ToDouble(value2));                    
                    break;
            }//end switch block    
             //Set the result to the value of what will be displayed.  
             //Also clear the value of value2
             //This will allow the user to perform mathematical operations in succession.          
            value1 = Convert.ToString(result);
            value2 = null;
            _operator = null;//clear the operator so the user will need
            return result;
        }//end method Calculate

        //method for adding values to the variables used for calculations.
        private void AddValue(string input)
        {
            if (value1 == null)
                value1 = input;
            else if (value2 == null)
                value2 = input;
            //this may be dead code...
            else
            {
                value1 = value2;
                value2 = input;
            }
        }//end method AddValue


        //methods for performing mathematical calculations.
        private double Addition(double a, double b)
        {
            return (a + b);
        }

        private double Subtraction(double a, double b)
        {
            return (a - b);
        }

        private double Multiplication(double a, double b)
        {
            return (a * b);
        }

        private double Division(double a, double b)
        {
            if (b != 0)
                return (a / b);
            else
            {
                ResultsTextBox.Text = "Cannot divide by zero";
                value1 = null;
                value2 = null;
                return 0;
            }
        }
        
        private void EqualsButton_Click(object sender, EventArgs e)
        {
            //Perform the calculation and display the result in the textBox 
            AddValue(EntryTextBox.Text);           
            EntryTextBox.Text = Calculate().ToString();
        }


        //OnClick methods for the Clear function
        private void ClearButton_Click(object sender, EventArgs e)
        {
            //clear the textbox
            EntryTextBox.Clear();
            ResultsTextBox.Clear();
            value1 = null;
            value2 = null;
        }
        private void ClearEverythingButton_Click(object sender, EventArgs e)
        {
            //clear the textbox and the memory
            EntryTextBox.Clear();
            ResultsTextBox.Clear();
            memory = null;
            value1 = null;
            value2 = null;
        }

        //OnClick methods for the Memory function
        private void MemoryClearButton_Click(object sender, EventArgs e)
        {
            //clear the memory
            memory = null;
        }

        private void MemoryRecallButton_Click(object sender, EventArgs e)
        {
            //Add the value in memory to the textbox if it is not null.  
            if (memory != null)
            {
                EntryTextBox.Clear();
                EntryTextBox.AppendText(memory);
            }
        }

        private void MemoryStoreButton_Click(object sender, EventArgs e)
        {           
           memory = EntryTextBox.Text;
           EntryTextBox.Clear();
        }


        //OnClick Listeners for Number Buttons 
        private void ZeroButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText ("0");
        }
        private void OneButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("1");
        }
        private void TwoButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("2");
        }
        private void ThreeButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("3");
        }
        private void FourButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("4");
        }
        private void FiveButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("5");
        }
        private void SixButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("6");
        }
        private void SevenButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("7");
        }
        private void EightButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("8");
        }
        private void NineButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText("9");
        }
        private void DotButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.AppendText(".");
        }

        //OnClick Listeners for Operations Buttons 
        private void AdditionButton_Click(object sender, EventArgs e)
        {
            //Deprecated functionality
            //EntryTextBox.AppendText(" + ");
            AddValue(EntryTextBox.Text);
            _operator = "+";
            EntryTextBox.Clear();
            ResultsTextBox.Clear();
        }
        private void SubtractionButton_Click(object sender, EventArgs e)
        {
            //EntryTextBox.AppendText(" - ");
            AddValue(EntryTextBox.Text);
            _operator = "-";
            EntryTextBox.Clear();
            ResultsTextBox.Clear();
        }
        private void MultiplicationButton_Click(object sender, EventArgs e)
        {
            //EntryTextBox.AppendText(" * ");
            AddValue(EntryTextBox.Text);
            _operator = "*";
            EntryTextBox.Clear();
            ResultsTextBox.Clear();
        }
        private void DivisionButton_Click(object sender, EventArgs e)
        {
            //EntryTextBox.AppendText(" / ");
            AddValue(EntryTextBox.Text);
            _operator = "/";
            EntryTextBox.Clear();
            ResultsTextBox.Clear();
        }       
        private void SquaredButton_Click(object sender, EventArgs e)
        {
            EntryTextBox.Text = Convert.ToString(Math.Pow(Convert.ToDouble(EntryTextBox.Text), 2));
            ResultsTextBox.Clear();
        }

        //Method for listening for button presses
        private void EntryTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.D0)
                EntryTextBox.AppendText("0");
            if (e.KeyCode == Keys.NumPad1 || e.KeyCode == Keys.D1)
                EntryTextBox.AppendText("1");
            if (e.KeyCode == Keys.NumPad2 || e.KeyCode == Keys.D2)
                EntryTextBox.AppendText("2");
            if (e.KeyCode == Keys.NumPad3 || e.KeyCode == Keys.D3)
                EntryTextBox.AppendText("3");
            if (e.KeyCode == Keys.NumPad4 || e.KeyCode == Keys.D4)
                EntryTextBox.AppendText("4");
            if (e.KeyCode == Keys.NumPad5 || e.KeyCode == Keys.D5)
                EntryTextBox.AppendText("5");
            if (e.KeyCode == Keys.NumPad6 || e.KeyCode == Keys.D6)
                EntryTextBox.AppendText("6");
            if (e.KeyCode == Keys.NumPad7 || e.KeyCode == Keys.D7)
                EntryTextBox.AppendText("7");
            if (e.KeyCode == Keys.NumPad8 || e.KeyCode == Keys.D8)
                EntryTextBox.AppendText("8");
            if (e.KeyCode == Keys.NumPad9 || e.KeyCode == Keys.D9)
                EntryTextBox.AppendText("9");
            if (e.KeyCode == Keys.Add || e.KeyCode == Keys.Oemplus)
            {
                AddValue(EntryTextBox.Text);
                _operator = "+";
                EntryTextBox.Clear();
                ResultsTextBox.Clear();
            }
            if (e.KeyCode == Keys.Subtract || e.KeyCode == Keys.OemMinus)
            {
                AddValue(EntryTextBox.Text);
                _operator = "-";
                EntryTextBox.Clear();
                ResultsTextBox.Clear();
            }
            if (e.KeyCode == Keys.Multiply)//Since the number 8 and * share the same key, there doesn't seem to be a way of getting the computer to distinguish between the tow since both will trigger the same key press.
            {
                AddValue(EntryTextBox.Text);
                _operator = "*";
                EntryTextBox.Clear();
                ResultsTextBox.Clear();
            }
            if (e.KeyCode == Keys.Divide || e.KeyCode == Keys.OemQuestion)
            {
                AddValue(EntryTextBox.Text);
                _operator = "/";
                EntryTextBox.Clear();
                ResultsTextBox.Clear();
            }
            if (e.KeyCode == Keys.Decimal || e.KeyCode == Keys.OemPeriod)
                EntryTextBox.AppendText(".");
            if (e.KeyCode == Keys.Enter)
            {
                //Perform the calculation and display the result in the textBox 
                AddValue(EntryTextBox.Text);
                EntryTextBox.Text = Calculate().ToString();
            }

        }//end method EntryTextBox_KeyDown

        /// <summary>
        /// The below methods are all rejects which didn't work for one reason or another.
        /// </summary>

        //These methods are created in the hopes that by simply having the Calculator Form be the focus,
        //One could enter numbers with buttons.  This did not turn out to be the case.
        //The form didn't seem to register any buttons being pressed.
        //Notice that KeyPressEventArgs class has the 'KeyChar' attribute while the KeyEventArgs class has the 'KeyCode' attribute.
        private void Calculator_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.Equals(Keys.NumPad0) || e.KeyChar.Equals(Keys.D0))
            EntryTextBox.AppendText("0");
        }
        private void Calculator_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.NumPad0 || e.KeyCode == Keys.D0)
                EntryTextBox.AppendText("0");
        }

        private void EntryTextBox_TextChanged(object sender, EventArgs e)
        {
            //accidentally created this method
        }


    }//end partial class Calculator : Form
}//end Namespace Crouch_Calculator
